/**
 * Bookings Router
 * Handles all booking-related API endpoints.
 * Uses in-memory store (no database required for assessment).
 */

const express = require('express');
const { v4: uuidv4 } = require('uuid');
const router = express.Router();

// ─── Constants ────────────────────────────────────────────────────────────────
const MAX_SEATS_PER_MOBILE_PER_DAY = 6;
const TOTAL_ROWS = 15;
const COLUMNS = ['A', 'B', 'C', 'D']; // 2×2 layout: A,B left | C,D right
const BOARDING_TIME_PER_GROUP_SECONDS = 60;

// ─── In-Memory Store ──────────────────────────────────────────────────────────
/** @type {Map<string, Booking>} key = bookingId */
const bookingsStore = new Map();

// ─── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Generates all valid seat IDs for the bus.
 * Format: A1 … A15, B1 … B15, C1 … C15, D1 … D15
 */
function getAllSeats() {
  const seats = [];
  for (const col of COLUMNS) {
    for (let row = 1; row <= TOTAL_ROWS; row++) {
      seats.push(`${col}${row}`);
    }
  }
  return seats;
}

/**
 * Validates a seat label against the bus layout.
 * @param {string} seat
 * @returns {boolean}
 */
function isValidSeat(seat) {
  if (typeof seat !== 'string') return false;
  const match = seat.match(/^([A-D])(\d+)$/);
  if (!match) return false;
  const row = parseInt(match[2], 10);
  return row >= 1 && row <= TOTAL_ROWS;
}

/**
 * Normalises a date string to YYYY-MM-DD.
 * @param {string} dateStr
 * @returns {string|null}
 */
function normaliseDate(dateStr) {
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return null;
    return d.toISOString().split('T')[0];
  } catch {
    return null;
  }
}

/**
 * Returns all bookings for a given travel date.
 * @param {string} travelDate  YYYY-MM-DD
 * @returns {Booking[]}
 */
function getBookingsForDate(travelDate) {
  return Array.from(bookingsStore.values()).filter(b => b.travelDate === travelDate);
}

/**
 * Returns the set of booked seat IDs for a given travel date,
 * optionally excluding a specific bookingId (for edit scenarios).
 * @param {string} travelDate
 * @param {string|null} excludeBookingId
 * @returns {Set<string>}
 */
function getBookedSeatsForDate(travelDate, excludeBookingId = null) {
  const booked = new Set();
  for (const b of bookingsStore.values()) {
    if (b.travelDate === travelDate && b.bookingId !== excludeBookingId) {
      b.seats.forEach(s => booked.add(s));
    }
  }
  return booked;
}

/**
 * Counts how many seats a mobile number has booked on a given date,
 * excluding a specific bookingId (for edit scenarios).
 * @param {string} mobile
 * @param {string} travelDate
 * @param {string|null} excludeBookingId
 * @returns {number}
 */
function countSeatsForMobile(mobile, travelDate, excludeBookingId = null) {
  return Array.from(bookingsStore.values())
    .filter(b => b.mobile === mobile && b.travelDate === travelDate && b.bookingId !== excludeBookingId)
    .reduce((sum, b) => sum + b.seats.length, 0);
}

/**
 * Extracts the numeric row from a seat label (e.g. "A7" → 7).
 * @param {string} seat
 * @returns {number}
 */
function getRow(seat) {
  return parseInt(seat.replace(/[A-D]/, ''), 10);
}

/**
 * Optimal Boarding Sequence Algorithm
 *
 * Strategy: Board passengers from the BACK of the bus to the FRONT.
 * This ensures no group blocks another group from reaching their seat.
 *
 * For groups with the same maximum row, secondary sort by the highest
 * seat number so the physically furthest seats board first.
 *
 * Time complexity: O(n log n) where n = number of bookings.
 *
 * @param {Booking[]} bookings
 * @returns {{ sequence: number, bookingId: string, seats: string[], mobile: string, totalTimeSeconds: number }[]}
 */
function computeOptimalBoardingSequence(bookings) {
  if (!bookings.length) return [];

  // Sort: highest max-row first (back-to-front boarding).
  // Tie-break: higher seat numbers first within the same row.
  const sorted = [...bookings].sort((a, b) => {
    const maxRowA = Math.max(...a.seats.map(getRow));
    const maxRowB = Math.max(...b.seats.map(getRow));
    if (maxRowB !== maxRowA) return maxRowB - maxRowA;
    // Tie-break: more seats = takes longer, so board first
    return b.seats.length - a.seats.length;
  });

  // Calculate total boarding time.
  // With optimal (back-to-front) sequence, only the LAST group (front)
  // is the bottleneck. Each group boards in parallel with those already seated.
  // Total time = number of groups × 60s (each group waits for the previous to settle).
  const totalTimeSeconds = sorted.length * BOARDING_TIME_PER_GROUP_SECONDS;

  return sorted.map((booking, idx) => ({
    sequence: idx + 1,
    bookingId: booking.bookingId,
    seats: booking.seats,
    mobile: booking.mobile,
    boarded: booking.boarded,
  })).concat([]).map((item, _, arr) => ({
    ...item,
    totalTimeSeconds: arr.length === arr.indexOf(item) + 1 ? totalTimeSeconds : undefined,
  }));
}

// ─── Routes ───────────────────────────────────────────────────────────────────

/**
 * GET /api/bookings/seats?travelDate=YYYY-MM-DD
 * Returns full seat layout with availability status.
 */
router.get('/seats', (req, res) => {
  const { travelDate } = req.query;
  if (!travelDate) {
    return res.status(400).json({ error: 'travelDate query parameter is required.' });
  }

  const date = normaliseDate(travelDate);
  if (!date) {
    return res.status(400).json({ error: 'Invalid travelDate format. Use YYYY-MM-DD.' });
  }

  const bookedSeats = getBookedSeatsForDate(date);
  const allSeats = getAllSeats();

  const layout = allSeats.map(seatId => ({
    seatId,
    column: seatId[0],
    row: parseInt(seatId.slice(1), 10),
    isBooked: bookedSeats.has(seatId),
  }));

  res.json({ travelDate: date, seats: layout, totalBooked: bookedSeats.size });
});

/**
 * GET /api/bookings?travelDate=YYYY-MM-DD
 * Returns all bookings for a date with optimal boarding sequence.
 */
router.get('/', (req, res) => {
  const { travelDate } = req.query;
  if (!travelDate) {
    return res.status(400).json({ error: 'travelDate query parameter is required.' });
  }

  const date = normaliseDate(travelDate);
  if (!date) {
    return res.status(400).json({ error: 'Invalid travelDate format. Use YYYY-MM-DD.' });
  }

  const bookings = getBookingsForDate(date);
  const boardingSequence = computeOptimalBoardingSequence(bookings);

  const totalTimeSeconds = bookings.length > 0
    ? bookings.length * BOARDING_TIME_PER_GROUP_SECONDS
    : 0;

  res.json({
    travelDate: date,
    bookings: boardingSequence,
    totalBookings: bookings.length,
    optimalBoardingTimeSeconds: totalTimeSeconds,
  });
});

/**
 * GET /api/bookings/:bookingId
 * Returns a single booking by ID.
 */
router.get('/:bookingId', (req, res) => {
  const booking = bookingsStore.get(req.params.bookingId);
  if (!booking) {
    return res.status(404).json({ error: `Booking ${req.params.bookingId} not found.` });
  }
  res.json(booking);
});

/**
 * POST /api/bookings
 * Creates a new booking.
 * Body: { travelDate, mobile, seats: string[] }
 */
router.post('/', (req, res) => {
  const { travelDate, mobile, seats } = req.body;

  // ── Validate required fields ──────────────────────────────────────────────
  if (!travelDate || !mobile || !seats) {
    return res.status(400).json({ error: 'travelDate, mobile, and seats are required.' });
  }

  const date = normaliseDate(travelDate);
  if (!date) {
    return res.status(400).json({ error: 'Invalid travelDate. Use YYYY-MM-DD.' });
  }

  // Must not be in the past
  const today = new Date().toISOString().split('T')[0];
  if (date < today) {
    return res.status(400).json({ error: 'Cannot book tickets for past dates.' });
  }

  // Validate mobile number (10 digits)
  if (!/^\d{10}$/.test(mobile)) {
    return res.status(400).json({ error: 'Mobile number must be exactly 10 digits.' });
  }

  // Validate seats array
  if (!Array.isArray(seats) || seats.length === 0) {
    return res.status(400).json({ error: 'At least one seat must be selected.' });
  }

  // Validate individual seat labels
  const invalidSeats = seats.filter(s => !isValidSeat(s));
  if (invalidSeats.length > 0) {
    return res.status(400).json({ error: `Invalid seat(s): ${invalidSeats.join(', ')}.` });
  }

  // Duplicate seats in request
  const uniqueSeats = [...new Set(seats)];
  if (uniqueSeats.length !== seats.length) {
    return res.status(400).json({ error: 'Duplicate seats in request.' });
  }

  // ── Business rules ────────────────────────────────────────────────────────
  const existingCount = countSeatsForMobile(mobile, date);
  if (existingCount + uniqueSeats.length > MAX_SEATS_PER_MOBILE_PER_DAY) {
    return res.status(400).json({
      error: `Maximum ${MAX_SEATS_PER_MOBILE_PER_DAY} seats allowed per mobile per day. You have ${existingCount} seat(s) already booked.`,
    });
  }

  const bookedSeats = getBookedSeatsForDate(date);
  const alreadyTaken = uniqueSeats.filter(s => bookedSeats.has(s));
  if (alreadyTaken.length > 0) {
    return res.status(409).json({ error: `Seat(s) already booked: ${alreadyTaken.join(', ')}.` });
  }

  // ── Create booking ────────────────────────────────────────────────────────
  const booking = {
    bookingId: uuidv4().split('-')[0].toUpperCase(),
    travelDate: date,
    mobile,
    seats: uniqueSeats,
    boarded: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  bookingsStore.set(booking.bookingId, booking);
  res.status(201).json(booking);
});

/**
 * PUT /api/bookings/:bookingId
 * Updates an existing booking (seats can be changed).
 * Body: { travelDate?, mobile?, seats? }
 */
router.put('/:bookingId', (req, res) => {
  const existing = bookingsStore.get(req.params.bookingId);
  if (!existing) {
    return res.status(404).json({ error: `Booking ${req.params.bookingId} not found.` });
  }

  const { travelDate, mobile, seats } = req.body;
  const date = travelDate ? normaliseDate(travelDate) : existing.travelDate;
  const newMobile = mobile || existing.mobile;
  const newSeats = seats || existing.seats;

  if (travelDate && !date) {
    return res.status(400).json({ error: 'Invalid travelDate.' });
  }

  const today = new Date().toISOString().split('T')[0];
  if (date < today) {
    return res.status(400).json({ error: 'Cannot update to a past date.' });
  }

  if (!/^\d{10}$/.test(newMobile)) {
    return res.status(400).json({ error: 'Mobile number must be exactly 10 digits.' });
  }

  if (!Array.isArray(newSeats) || newSeats.length === 0) {
    return res.status(400).json({ error: 'At least one seat must be selected.' });
  }

  const invalidSeats = newSeats.filter(s => !isValidSeat(s));
  if (invalidSeats.length > 0) {
    return res.status(400).json({ error: `Invalid seat(s): ${invalidSeats.join(', ')}.` });
  }

  const uniqueSeats = [...new Set(newSeats)];

  const existingCount = countSeatsForMobile(newMobile, date, req.params.bookingId);
  if (existingCount + uniqueSeats.length > MAX_SEATS_PER_MOBILE_PER_DAY) {
    return res.status(400).json({
      error: `Maximum ${MAX_SEATS_PER_MOBILE_PER_DAY} seats per mobile per day. You already have ${existingCount} other booking(s).`,
    });
  }

  const bookedSeats = getBookedSeatsForDate(date, req.params.bookingId);
  const alreadyTaken = uniqueSeats.filter(s => bookedSeats.has(s));
  if (alreadyTaken.length > 0) {
    return res.status(409).json({ error: `Seat(s) already taken: ${alreadyTaken.join(', ')}.` });
  }

  const updated = {
    ...existing,
    travelDate: date,
    mobile: newMobile,
    seats: uniqueSeats,
    updatedAt: new Date().toISOString(),
  };

  bookingsStore.set(req.params.bookingId, updated);
  res.json(updated);
});

/**
 * PATCH /api/bookings/:bookingId/board
 * Marks a booking as boarded.
 */
router.patch('/:bookingId/board', (req, res) => {
  const booking = bookingsStore.get(req.params.bookingId);
  if (!booking) {
    return res.status(404).json({ error: `Booking ${req.params.bookingId} not found.` });
  }

  if (booking.boarded) {
    return res.status(400).json({ error: 'Booking is already marked as boarded.' });
  }

  const updated = { ...booking, boarded: true, boardedAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
  bookingsStore.set(req.params.bookingId, updated);
  res.json(updated);
});

/**
 * DELETE /api/bookings/:bookingId
 * Cancels a booking.
 */
router.delete('/:bookingId', (req, res) => {
  const booking = bookingsStore.get(req.params.bookingId);
  if (!booking) {
    return res.status(404).json({ error: `Booking ${req.params.bookingId} not found.` });
  }

  bookingsStore.delete(req.params.bookingId);
  res.json({ message: `Booking ${req.params.bookingId} cancelled successfully.` });
});

module.exports = router;

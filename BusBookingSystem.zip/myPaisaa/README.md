# myPaisaa – Bus Ticket Booking System

> **Assessment Submission** — Angular 16 + Node.js/Express

---

## Project Overview

A full-stack Bus Ticket Booking System for a **Bus Conductor**, featuring:

- **Screen 1 – Book / Update / Edit Booking**: Interactive 2×2 seat map (15 rows, 60 seats), mobile validation, per-mobile seat limit, live availability, edit existing bookings, and a confirmation popup.
- **Screen 2 – Booking List & Boarding Tracking**: Date-filtered list with optimal boarding sequence, one-tap call initiation, and boarding status tracking.
- **Optimal Boarding Algorithm**: Back-to-front sequencing that minimises total boarding time (O(n log n)).

---

## Tech Stack

| Layer    | Technology           |
|----------|----------------------|
| Frontend | Angular 16, SCSS, RxJS, Reactive Forms |
| Backend  | Node.js 18+, Express 4, UUID |
| Storage  | In-memory (no DB required) |

---

## Project Structure

```
myPaisaa/
├── backend/
│   ├── server.js              # Express app entry point
│   ├── routes/
│   │   └── bookings.js        # All booking endpoints + algorithm
│   └── package.json
│
├── frontend/
│   ├── angular.json
│   ├── tsconfig.json
│   ├── package.json
│   └── src/
│       ├── main.ts
│       ├── index.html
│       ├── styles.scss        # Global CSS variables & reset
│       ├── environments/
│       │   ├── environment.ts
│       │   └── environment.prod.ts
│       └── app/
│           ├── app.module.ts
│           ├── app-routing.module.ts
│           ├── app.component.*
│           ├── models/
│           │   └── booking.model.ts
│           ├── services/
│           │   └── booking.service.ts
│           └── components/
│               ├── book-ticket/      # Screen 1
│               └── booking-list/     # Screen 2
│
└── README.md
```

---

## Setup & Execution

### Prerequisites

| Tool | Version |
|------|---------|
| Node.js | 18.x or higher |
| npm | 9.x or higher |
| Angular CLI | 16.x (`npm install -g @angular/cli@16`) |

---

### Step 1 – Start the Backend

```bash
cd myPaisaa/backend
npm install
npm start
```

The API will start at: **http://localhost:3000**

Health check: http://localhost:3000/api/health

---

### Step 2 – Start the Frontend

Open a **new terminal**:

```bash
cd myPaisaa/frontend
npm install
ng serve
```

The app will open at: **http://localhost:4200**

> Angular CLI will proxy API calls to the backend automatically (both run independently; CORS is pre-configured).

---

### Step 3 – Use the App

1. Open **http://localhost:4200** in your browser.
2. Navigate to **Book Ticket** (Screen 1):
   - Select a travel date
   - Enter a 10-digit mobile number
   - Click seats on the bus layout (max 6 per mobile per day)
   - Click **Confirm Booking** → see the confirmation popup
3. Navigate to **Booking List** (Screen 2):
   - Select the same travel date and click **Search**
   - View bookings sorted by the optimal boarding algorithm
   - Click 📱 to call a passenger
   - Click **Mark Boarded** to update boarding status

---

## API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Health check |
| GET | `/api/bookings/seats?travelDate=YYYY-MM-DD` | Seat availability |
| GET | `/api/bookings?travelDate=YYYY-MM-DD` | All bookings with boarding order |
| GET | `/api/bookings/:bookingId` | Single booking |
| POST | `/api/bookings` | Create booking |
| PUT | `/api/bookings/:bookingId` | Update booking |
| PATCH | `/api/bookings/:bookingId/board` | Mark as boarded |
| DELETE | `/api/bookings/:bookingId` | Cancel booking |

**POST /api/bookings body:**
```json
{
  "travelDate": "2024-12-25",
  "mobile": "9876543210",
  "seats": ["A3", "B3"]
}
```

---

## Optimal Boarding Algorithm

**Problem**: Determine the boarding sequence that minimises total time for all passengers to board.

**Strategy**: Board passengers from the **back of the bus to the front** (highest row number first).

**Why it works**:
- Passengers heading to the front board last — they never block anyone behind them.
- Passengers heading to the back board first — no one is in their way.
- With this sequence, the settling time of each group overlaps with the walking time of the next group entering.
- **Total time = number of booking groups × 60 seconds** (only the last group's settling time is sequential).

**Example from the assessment spec:**

| Sequence | Booking ID | Seat | Reason |
|----------|-----------|------|--------|
| 1 | 333 | A15 | Furthest back — boards first |
| 2 | 222 | A7 | Middle row — boards second |
| 3 | 111 | A1 | Front row — boards last |

**Result**: Total time = 60 seconds (optimal) vs 180 seconds (non-optimal).

**Complexity**: O(n log n) — single sort by max row number descending.

---

## Business Rules & Validations

| Rule | Detail |
|------|--------|
| Max seats per mobile per day | 6 |
| Seat layout | 2×2, columns A–D, rows 1–15 (60 seats total) |
| Mobile format | Exactly 10 digits |
| Travel date | Cannot be in the past |
| Seat conflicts | Duplicate seat bookings are rejected with a 409 |
| Boarding | Once marked boarded, cannot be undone |

---

## Assumptions Made

1. The bus has a **single front entry gate** — boarding order matters.
2. **All passengers under the same Booking ID board together** as a group.
3. Each group takes exactly **60 seconds to settle** before the next group can pass.
4. **Walking time inside the bus is negligible**.
5. Data is stored **in-memory** (resets on server restart) — suitable for assessment.
6. The system is used by a **conductor** (admin), so no authentication is required.
7. A mobile number can book seats across **multiple Booking IDs** on the same day, up to a combined limit of 6.

---

## Summary

| Item | Value |
|------|-------|
| Project | myPaisaa Bus Ticket Booking System |
| Frontend | Angular 16, SCSS, Reactive Forms, RxJS |
| Backend | Node.js + Express, in-memory store |
| Algorithm | Back-to-front O(n log n) optimal boarding |
| Screens | 2 (Book Ticket + Booking List) |
| Validations | Mobile, date, seat limit, conflicts, edge cases |
